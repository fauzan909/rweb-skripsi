<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Uji extends CI_Controller {
	public function index() {
		echo tambah_jam_sql(145);
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */